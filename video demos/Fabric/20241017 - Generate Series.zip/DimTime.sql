DROP TABLE IF EXISTS dbo.DimTimeSQL
GO
CREATE TABLE dbo.DimTimeSQL
(
    TimeKey varchar(8) NULL,
    [Actual TIME] VARCHAR(5) NULL,
    [Hour] INT NULL,
    [Hour Extended] VARCHAR(10) NULL,
    [Minute] INT NULL,
    AMPM VARCHAR(5) NULL
)
GO
DECLARE @sd datetime = '2024-01-01 23:59:00';


INSERT INTO dbo.DimTimeSQL
SELECT
    CAST(FORMAT(dateadd(mi, [value], @sd),'HHmm') AS VARCHAR(4)) TimeKey,
    CAST(FORMAT(dateadd(mi, [value], @sd), N'HH\:mm tt') AS TIME(4)) [Actual Time],
    CAST(FORMAT(dateadd(mi, [value], @sd),'HH') AS INT) [Hour],
    CAST(FORMAT(dateadd(mi, [value], @sd),'HH tt') AS VARCHAR(6)) [Hour Extended],
    CAST(FORMAT(dateadd(mi, [value], @sd),'mm') AS INT) [Minute],
    CAST(FORMAT(dateadd(mi, [value], @sd),'tt') AS VARCHAR(2)) [AMPM]
FROM dbo.fn_RowKey(1, 1440, 1)