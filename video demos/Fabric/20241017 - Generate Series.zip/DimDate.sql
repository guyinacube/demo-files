DROP TABLE IF EXISTS dbo.DimDate
GO
CREATE TABLE dbo.DimDate
(
    DateKey varchar(10),
    [Actual Date] date,
    [Year] int,
    [QuarterNum] int,
    [Quarter] varchar(7),
    [MonthNum] int,
    [Month] varchar(15),
    [WeekDayNum] int,
    [WeekDay] varchar(15)
)
GO

DECLARE
    @StartDate DateTime = '1/1/2024',
    @EndDate DateTime = '12/31/2024',
    @StartInt int,
    @EndInt int

SELECT
    @StartInt = CAST(@StartDate AS INT),
    @EndInt = CAST(@EndDate AS INT) ;

WITH Days
AS
(
    SELECT 
        CAST(CAST(value as datetime) AS DATE) [Actual Date]
    FROM GENERATE_SERIES(@StartInt, @EndInt, 1)
)
INSERT INTO DimDate
SELECT 
    [Actual Date]  [DateKey],
    [Actual Date],
    YEAR([Actual Date]) [Year],
    DATEPART(QUARTER, [Actual Date]) [QuarterNum],
    'QTR '+ CAST(DATEPART(QUARTER, [Actual Date]) AS VARCHAR) [Quater],
    MONTH([Actual Date]) [MonthNum],
    DATENAME(MONTH, [Actual Date]) [Month],
    DATEPART(dw, [Actual Date]) [WeekDayNum],
    DATENAME(dw, [Actual Date]) [WeekDday]
FROM Days