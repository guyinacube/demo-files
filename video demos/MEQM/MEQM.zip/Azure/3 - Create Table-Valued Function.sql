DROP FUNCTION IF EXISTS dbo.fn_xe_MEQM
GO
CREATE FUNCTION dbo.fn_xe_MEQM(@file nvarchar(400))
RETURNS TABLE
RETURN WITH Results (incrinfo, EventTime) as
(
SELECT CAST(C.query('.') AS XML) AS WaitInfo, C.query('.').value('(/event/@timestamp)[1]', 'varchar(255)') 
        FROM (SELECT
                CAST(event_data AS XML) AS XMLDATA 
            FROM
                sys.fn_xe_file_target_read_file(    
               @file, null, null, null)) a
        CROSS APPLY a.XMLDATA.nodes('/event') as T(C)
        WHERE C.query('.').value('(/event/@name)[1]', 'varchar(255)') = 'sql_batch_completed'
	)
SELECT 
	incrinfo.value('(//event/action[@name="username"]/value)[1]', 'varchar(100)') as Username,
	incrinfo.value('(//event/action[@name="client_app_name"]/value)[1]', 'varchar(100)') as Client,
	incrinfo.value('(//event/action[@name="database_name"]/value)[1]', 'varchar(100)') as [Database_Name],
	incrinfo.value('(//event/action[@name="client_pid"]/value)[1]', 'varchar(100)') as Client_PID,
	incrinfo.value('(//event/action[@name="sql_text"]/value)[1]', 'varchar(max)') as SQL_Statement,
	incrinfo.value('(//event/data[@name="row_count"]/value)[1]', 'int') as Row_count,
	incrinfo.value('(//event/data[@name="duration"]/value)[1]', 'int') as Duration,
	incrinfo.value('(//event/data[@name="writes"]/value)[1]', 'int') as Writes,
	incrinfo.value('(//event/data[@name="cpu_time"]/value)[1]', 'int') as CPU_Time,	
	incrinfo.value('(//event/data[@name="physical_reads"]/value)[1]', 'int') as Physical_Reads,
	incrinfo.value('(//event/data[@name="logical_reads"]/value)[1]', 'int') as Logical_Reads,
	EventTime
FROM Results