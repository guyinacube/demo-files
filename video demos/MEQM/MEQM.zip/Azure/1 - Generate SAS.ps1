﻿$subscriptionName='*****ADD YOUR OWN VALUE*****'   # the name  of subscription name you will use  
$locationName = '*****ADD YOUR OWN VALUE*****'  # the data center region you will use  
$storageAccountName= '*****ADD YOUR OWN VALUE*****' # the storage account name you will create or use  
$containerName= '*****ADD YOUR OWN VALUE*****'  # the storage container name to which you will attach the SAS policy with its SAS token  
$policyName = '*****ADD YOUR OWN VALUE*****' # the name of the SAS policy  
$resourceGroupName = "*****ADD YOUR OWN VALUE*****"


# adds an authenticated Azure account for use in the session   
Login-AzureRmAccount    

# set the tenant, subscription and environment for use in the rest of   
Set-AzureRmContext -SubscriptionName $subscriptionName 

#Add-AzureAccount  

#Select-AzureSubscription -SubscriptionName $subscriptionName #provide an existing classic storage account  
#$accountKeys = Get-AzureStorageKey -StorageAccountName $storageAccountName  
#$storageContext = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $accountKeys.Primary  

# Get the access keys for the ARM storage account  
$accountKeys = Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroupName -Name $storageAccountName  

# Create a new storage account context using an ARM storage account  
$storageContext = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $accountKeys[0].Value 
# The remainder of this script works with either the ARM or classic sections of code above  

# Creates a new container in blob storage  
#$container = New-AzureStorageContainer -Context $storageContext -Name $containerName  

# Sets up a Stored Access Policy and a Shared Access Signature for the new container  
$policy = New-AzureStorageContainerStoredAccessPolicy -Container $containerName -Policy $policyName -Context $storageContext -StartTime $(Get-Date).ToUniversalTime().AddMinutes(-5) -ExpiryTime $(Get-Date).ToUniversalTime().AddYears(10) -Permission rwld

# Gets the Shared Access Signature for the policy  
$sas = New-AzureStorageContainerSASToken -name $containerName -Policy $policyName -Context $storageContext
Write-Host 'Shared Access Signature= '$($sas.Substring(1))''  

# Outputs the Transact SQL to the clipboard and to the screen to create the credential using the Shared Access Signature  
Write-Host 'Credential T-SQL'  
$tSql = "CREATE DATABASE SCOPED CREDENTIAL [{0}] WITH IDENTITY='Shared Access Signature', SECRET='{1}'" -f $cbc.Uri,$sas.Substring(1)   
$tSql | clip  
Write-Host $tSql