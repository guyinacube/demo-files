

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name = 'XE_MEQM')
BEGIN
	DROP EVENT SESSION [XE_MEQM] ON SERVER 
END
GO

CREATE EVENT SESSION [XE_MEQM] ON SERVER 
ADD EVENT sqlserver.sql_batch_completed(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.client_pid,sqlserver.sql_text,sqlserver.username, sqlserver.database_name)
    WHERE ([sqlserver].[like_i_sql_unicode_string]([sqlserver].[client_app_name],N'%Microsoft� Mashup Runtime%') OR [sqlserver].[like_i_sql_unicode_string]([sqlserver].[client_app_name],N'%Mashup Engine%')))
ADD TARGET package0.event_file(SET filename=N'*****ADD YOUR OWN VALUE*****\meqm.xel') --BLOB LOCATION FOR AZURE SQL and LOCAL DIRECTORY FOR Microsoft SQL Server
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=3 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

ALTER EVENT SESSION [XE_MEQM]
	ON SERVER
	STATE = START;
GO

