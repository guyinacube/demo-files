drop table if exists hosp_encounters;
drop table if exists hosp_appointments;
drop table if exists hosp_patients;

create table hosp_encounters
(
	EncounterID int identity(1,1),
	Encounter varchar(50),
	EncounterDate date,
	PatientID int
)
go

create table hosp_appointments
(
	AppointmentId int identity(1,1),
	Appointment varchar(50),
	AppointmentDate date,
	PatientID int
)
go

create table hosp_patients
(
	PatientID int,
	FirstName varchar(50),
	LastName varchar(50)
)
go

insert into hosp_encounters
values
	('Encounter1', '1/14/2025',1),
	('Encounter2', '1/3/2025',1),
	('Encounter3', '2/1/2025', 3);


insert into hosp_appointments
values
	('Appointment1', '1/7/2025', 2),
	('Appointment2', '1/13/2025', 3),
	('Appointment3', '2/11/2025', 2);

insert into hosp_patients
values
	(1, 'Patient', 'One'),
	(2, 'Patient', 'Two'),
	(3, 'Patient', 'Three')


	insert into hosp_appointments
values
	('Appointment1', '3/7/2025', 1),
	('Appointment2', '4/13/2025', 2),
	('Appointment3', '5/11/2025', 3);